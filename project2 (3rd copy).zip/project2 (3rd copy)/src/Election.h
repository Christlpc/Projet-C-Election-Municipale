#include<gtk/gtk.h>

typedef struct {
    int jour;
    int mois;
    int annee;

 }Date;
 typedef struct {
    char Localite[50] ;
    Date date;
    int Population;
    int Nombre_Conseiller;
    char ID;

}Election ;

void ajouter(char * filename, Election E );
void modifier(char * filename, char ID,Election New);
void supprimer(char * filename, char ID);
void chercher(char * filename, char ID);
void afficher_election(GtkWidget *liste);
