#include <gtk/gtk.h>


void
on_connexion_pierre_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_gardersession_pierre_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_G_Liste_Aziz_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_G_Election_pierre_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_G_reclamatiion_Majdi_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_G_utilisateur_Ramadan_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_G_bureauxvote_Omar_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_pierre_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_Ajouter_Election_pierre_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_Modifier_Election_pierre_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_Supprimer_Election_pierre_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_chercher_election_pierre_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_Ajouter_pierre_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour_pierre_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_Modifier_pierre_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_Retour_pierre_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_non_pierre_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_oui_pierre_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Supprimer_pierre_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_Ajouter_Omar_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_Retour_Omar_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_AJout_Adapt___personnes_besoins_speciaux_Omar_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Ajout_Avec_salle_attente_Omar_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Ajout_Support_wifi_Omar_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton6_Omar_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Modifier_Adapte_aux_personnes_besoins_speciaux_Omar_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Modifier_avec_salle_attente_Omar_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Modifier_Omar_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button10_pierre_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_Ajouter_agent_Omar_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview2_Omar_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_Ajouter_bureaux_Omar_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_Modifier_bureaux_Omar_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_Supprimer_bureaux_Omar_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_Chercher_bureaux_Omar_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_Supprimer_Omar_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_voulez_vous_supprimer_Omar_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview3_Ramadan_row_activated     (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_Ajouter_users_Ramadan_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_Modifier_users_Ramadan_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_Supprimer_ussers_Ramadan_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_chercher_users_Ramadan_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_AJout_Genre_femme_Ramadan_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_AJout_Genre_homme_Ramadan_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Retour_Ramadan_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_Ajout_Ramadan_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_Modifier_Genre_femme_Ramadan_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Modifier_Genre_Homme_Ramadan_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Moodifier_Ramadan_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_Confirmer_suppression_Ramadan_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_Supprimer_Ramadan_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_Ajouter_Majdi_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_Retour_Majdi_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_Modifier_Majdi_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_Supprimer_Majdi_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_Confirmer_suppression_Majdi_clicked (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview4_Majdi_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_Ajouter_reclamation_Majdi_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_Modifier_reclamation_Majdi_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_SUpprimer_reclamation_Majdi_clicked (GtkButton       *button,
                                        gpointer         user_data);

void
on_Chercher_Majdi_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview5_Aziz_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_Ajouter_liste_Aziz_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_Modifier_liste_Aziz_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_Supprimer_liste_Aziz_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_vote_Aziz_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_Chercher_Aziz_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_Retour_Aziz_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_Ajouter_Aziz_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_Modifier_Aziz_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_Suppression_confirmer_Aziz_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_Supprimer_Aziz_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_Electeur_bureau_Omar_row_activated  (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_Nombre_vote_liste_Ramadan_row_activated
                                        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_Conseillers_gagants_Aziz_row_activated
                                        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_Liste_selon_ordre_Ramadan_row_activated
                                        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);
