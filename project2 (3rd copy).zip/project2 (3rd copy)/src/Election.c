#include "Election.h"
#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>

enum
{
	ELocalite,
	Edate,
	EPopulation,
	ENombre_Conseiller,
	EID,
	Column,
};

void ajouter(char * filename, Election E )
{
  FILE * f=fopen(filename , "a");
    if(f!=NULL)
    {
        fprintf(f,"%s %d %d %d %d %d %s \n",E.Localite,E.date.jour,E.date.mois,E.date.annee,E.Population,E.Nombre_Conseiller,E.ID);
        fclose(f);
        return 1;
    }
    else return 0;
}

void modifier(char * filename, char ID,Election New)
{
    int tr=0;
    Election E;

    FILE * f=fopen(filename, "r");
    FILE * f2=fopen("New.txt", "w");
    if(f!=NULL && f2!=NULL)
    {
        while(fscanf(f,"%s %d %d %d %d %d %s  \n",E.Localite,&E.date.jour,&E.date.mois,&E.date.annee,&E.Population,&E.Nombre_Conseiller,E.ID)!=EOF)
        {
            if(E.ID== ID)
            {
                fprintf(f2," %s %d %d %d %d %d %s \n",New.Localite,New.date.jour,New.date.mois,New.date.annee,New.Population,New.Nombre_Conseiller,New.ID);
                tr=1;
            }
            else
                fprintf(f2," %s %d %d %d %d %d %s \n",E.Localite,E.date.jour,E.date.mois,E.date.annee,E.Population,E.Nombre_Conseiller,E.ID);

        }
    }
    fclose(f);
    fclose(f2);
    remove(filename);
    rename("New.txt", filename);
    return tr;
}

void supprimer(char * filename, char ID)
{
 int tr=0;
    Election E;
    FILE * f=fopen(filename, "r");
    FILE * f2=fopen("New.txt", "w");
    if(f!=NULL && f2!=NULL)
    {
        while(fscanf(f," %s %d %d %d %d %d %s \n",E.Localite,&E.date.jour,&E.date.mois,&E.date.annee,&E.Population,&E.Nombre_Conseiller,E.ID)!=EOF)
        {
            if(E.ID== ID)
                tr=1;
            else
                fprintf(f2," %s %d %d %d %d %d %s \n",E.Localite,E.date.jour,E.date.mois,E.date.annee,E.Population,E.Nombre_Conseiller,E.ID);
        }
    }
    fclose(f);
    fclose(f2);
    remove(filename);
    rename("New.txt", filename);
    return tr;
}
void chercher(char * filename, char ID)
{
}

void afficher_election(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter *Iter;
GtkListStore *store;
char Localite[50] ;
Date date;
int Population;
int Nombre_Conseiller;
char ID[20];
store=NULL;
FILE *f;
store=gtk_tree_view_get_model(liste);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" Localite ", renderer ,"text",ELocalite,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" date ", renderer ,"text",Edate,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" Population ", renderer ,"text",EPopulation,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" Nombre_Conseiller ", renderer ,"text",ENombre_Conseiller,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" ID ", renderer ,"text",EID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

store = gtk_list_store_new (Column G_TYPE_STRING , G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

f=fopen("Election.txt","r");
if(f==NULL)
{
	return;

}
else
{
f=fopen("Election.txt","a");
while(fscanf(f "%s %s %d %d %d %d %d \n",Localite,ID,&date.jour,&date.mois,&date.annee,&Population,&Nombre_Conseiller)!=EOF)
{
	gtk_list_store_append(store, &Iter);
	gtk_list_store_set(store, &Iter ,ELocalite,Localite,&Edate.jour,&date.jour,&Edate.mois,&date.mois,&Edate.annee,&date.annee,&EPopulation,&Population,&ENombre_Conseiller,&Nombre_Conseiller,EID,EID,-1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW(liste),(GTK_TREE_MODEL (store)));
g_object_unref (store);
}
}
