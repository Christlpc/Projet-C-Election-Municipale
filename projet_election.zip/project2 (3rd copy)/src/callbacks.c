#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "Election.h"


void
on_connexion_pierre_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
  GtkWidget *identifiantconx_pierre;
  GtkWidget *motdepasseconx_pierre;
  identifiantconx_pierre=lookup_widget(objet,"identifiantconx_pierre");
  strcpy(U.ID,gtk_entry_get_text(GTK_ENTRY(identifiantconx_pierre)));
  motdepasseconx_pierre=lookup_widget(objet,"motdepasseconx_pierre");
  strcpy(U.motdepasse,gtk_entry_get_text(GTK_ENTRY(motdepasseconx_pierre)));
  if(U.motdepasse=1)
	 GtkWidget *window1;
	 GtkWidget *window2;
	 window2 = lookup_widget(button, "window1");
	 gtk_widget_hide (window1);
	 window2= create_window2 ();
	 gtk_widget_show (window2);

}


void
on_gardersession_pierre_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_G_Liste_Aziz_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_G_Election_pierre_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
	 GtkWidget *window2;
	 GtkWidget *window3;
	 window2 = lookup_widget(button, "window2");
	 gtk_widget_hide (window2);
	 window3= create_window3 ();
	 gtk_widget_show (window3);
}


void
on_G_reclamatiion_Majdi_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_G_utilisateur_Ramadan_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_G_bureauxvote_Omar_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_treeview1_pierre_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter ;
	gchar* Localite ;
	gint* date;
	gint* population
	gint* Nombre_conseillers;
	gint* ID;
	Elction E;
	GtkTreeMode1 *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model, &iter, path))
{
	//obtentton des valeurs de la ligne selectionnée
		gtk_tree_model_get (GTK_LIST_STORE(model)  &iter, O, &ID, 1,&Localite,2,&date,3,&population,4,Nombre_conseillers, -1) ;
		// copie des valeurs dans la variable p de type personne pour le passer à la fonction de suppression
		strcpy(E.Localite, Localite) ;
		E.date=date;
		E.population=population;
		E.Nombre_conseillers=Nombre_conseillers;
		E.ID=ID.
		//appel de la fonction de suppression
		supprimer_election(E);
		// mise à jour de l'affichage de la treeview
		affiche_election( treeview) ;
}
}

void
on_Ajouter_Election_pierre_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{
 	 GtkWidget *window3;
	 GtkWidget *window4;
	 window3 = lookup_widget(button, "window3");
	 gtk_widget_hide (window3);
	 window4= create_window4 ();
	 gtk_widget_show (window4);
}


void
on_Modifier_Election_pierre_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{
	 GtkWidget *window3;
	 GtkWidget *window6;
	 window3 = lookup_widget(button, "window3");
	 gtk_widget_hide (window3);
	 window4= create_window6 ();
	 gtk_widget_show (window6);
}


void
on_Supprimer_Election_pierre_clicked   (GtkButton       *button,
                                        gpointer         user_data)
{
	 GtkWidget *window3;
	 GtkWidget *window5;
	 window3 = lookup_widget(button, "window3");
	 gtk_widget_hide (window3);
	 window4= create_window5 ();
	 gtk_widget_show (window5);
}


void
on_chercher_election_pierre_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Ajouter_pierre_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *localit___pierre;
GtkWidget *ID_pierre;
GtkWidget *Date_jour_pierre;
GtkWidget *Date_mois_pierre;
GtkWidget *Date_annee_pierre;
GtkWidget *population_pierre;
GtkWidget *Nbrconseiller_pierre;
GtkWidget *fenetre_ajout;
fenetre_ajout=lookup_widget(objet, " fenetre_ajout" ) ;
localit__pierre=lookup_widget(objet,"Localite");
ID_pierre=lookup_widget(objet,"ID");
Date_jour_pierre=lookup_widget(objet,"Date_jour_pierre");
Date_mois_pierre=lookup_widget(objet,"Date_mois_pierre");
Date_annee_pierre=lookup_widget(objet,"Date_annee_pierre");
population_pierre=lookup_widget(objet,"population");
Nbrconseiller_pierre=lookup_widget(objet,"Nbrconseiller");

strcpy(E.Localite,gtk_entry_get_text(GTK_ENTRY(localit___pierre;)));
strcpy(E.ID,gtk_entry_get_text(GTK_ENTRY(ID_pierre)));
E.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON());
E.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
E.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
strcpy(E.Nbrconseiller,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Nbrconseiller_pierre));
strcpy(E.population,gtk_combo_box_get_active_text(GTK_COMBO_BOX(population_pierre));

ajouter_election(E);

}


void
on_retour_pierre_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
	 GtkWidget *window3;
	 GtkWidget *window4;
	 window4 = lookup_widget(button, "window4");
	 gtk_widget_hide (window4);
	 window3= create_window3 ();
	 gtk_widget_show (window3);
}


void
on_Modifier_pierre_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *localit___pierre;
GtkWidget *ID_pierre;
GtkWidget *Date_jour_pierre;
GtkWidget *Date_mois_pierre;
GtkWidget *Date_annee_pierre;
GtkWidget *population_pierre;
GtkWidget *Nbrconseiller_pierre;
GtkWidget *fenetre_ajout;
fenetre_ajout=lookup_widget(objet, " fenetre_ajout" ) ;
localit__pierre=lookup_widget(objet,"Localite");
ID_pierre=lookup_widget(objet,"ID");
Date_jour_pierre=lookup_widget(objet,"Date_jour_pierre");
Date_mois_pierre=lookup_widget(objet,"Date_mois_pierre");
Date_annee_pierre=lookup_widget(objet,"Date_annee_pierre");
population_pierre=lookup_widget(objet,"population");
Nbrconseiller_pierre=lookup_widget(objet,"Nbrconseiller");

strcpy(E.Localite,gtk_entry_get_text(GTK_ENTRY(localit___pierre;)));
strcpy(E.ID,gtk_entry_get_text(GTK_ENTRY(ID_pierre)));
E.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
E.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
E.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
strcpy(E.Nbrconseiller,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Nbrconseiller_pierre));
strcpy(E.population,gtk_combo_box_get_active_text(GTK_COMBO_BOX(population_pierre));

Modifier_election(E);

}


void
on_Retour_pierre_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
	 GtkWidget *window3;
	 GtkWidget *window5;
	 window5 = lookup_widget(button, "window5");
	 gtk_widget_hide (window5);
	 window3= create_window3 ();
	 gtk_widget_show (window3);
}


void
on_non_pierre_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(oui_pierre))
		oui_non=0;
}


void
on_oui_pierre_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(oui_pierre))
		oui_non=1;
}


void
on_Supprimer_pierre_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Supp_ID_Election_pierre;
Supp_ID_Election_pierre=lookup_widget(objet,"Supp_ID_Election_pierre");
strcpy(ID,gtk_entry_get_text(GTK_ENTRY(ID_pierre)));
int supprimer(char * filename, int ID);

}


void
on_Ajouter_Omar_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Retour_Omar_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_AJout_Adapt___personnes_besoins_speciaux_Omar_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_Ajout_Avec_salle_attente_Omar_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_Ajout_Support_wifi_Omar_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_radiobutton6_Omar_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_Modifier_Adapte_aux_personnes_besoins_speciaux_Omar_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_Modifier_avec_salle_attente_Omar_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_Modifier_Omar_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button10_pierre_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Ajouter_agent_Omar_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_treeview2_Omar_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_Ajouter_bureaux_Omar_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Modifier_bureaux_Omar_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Supprimer_bureaux_Omar_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Chercher_bureaux_Omar_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Supprimer_Omar_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_voulez_vous_supprimer_Omar_clicked  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_treeview3_Ramadan_row_activated     (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_Ajouter_users_Ramadan_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Modifier_users_Ramadan_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Supprimer_ussers_Ramadan_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_chercher_users_Ramadan_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_AJout_Genre_femme_Ramadan_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_AJout_Genre_homme_Ramadan_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_Retour_Ramadan_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Ajout_Ramadan_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Modifier_Genre_femme_Ramadan_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_Modifier_Genre_Homme_Ramadan_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_Moodifier_Ramadan_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Confirmer_suppression_Ramadan_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Supprimer_Ramadan_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Ajouter_Majdi_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Retour_Majdi_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Modifier_Majdi_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Supprimer_Majdi_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Confirmer_suppression_Majdi_clicked (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_treeview4_Majdi_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_Ajouter_reclamation_Majdi_clicked   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Modifier_reclamation_Majdi_clicked  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_SUpprimer_reclamation_Majdi_clicked (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Chercher_Majdi_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_treeview5_Aziz_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_Ajouter_liste_Aziz_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Modifier_liste_Aziz_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Supprimer_liste_Aziz_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_vote_Aziz_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Chercher_Aziz_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Retour_Aziz_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Ajouter_Aziz_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Modifier_Aziz_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Suppression_confirmer_Aziz_clicked  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Supprimer_Aziz_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Electeur_bureau_Omar_row_activated  (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_Nombre_vote_liste_Ramadan_row_activated
                                        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_Conseillers_gagants_Aziz_row_activated
                                        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_Liste_selon_ordre_Ramadan_row_activated
                                        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}

